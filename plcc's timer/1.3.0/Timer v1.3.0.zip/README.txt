For installation tutorial, check the thread from Nakano_liuhai in the forum section of speedrun.com/hff :

https://www.speedrun.com/hff/thread/no8bs


TIMER OPTIONS :

When installation is completed, you must activate TIMER OPENED / AUTO RESET / TIME WHEN PAUSED (timer continues even when you hit ESC)

TIME IN MENU must be activated when running achievement% for exemple.

LITE MODE can be used if you're running individual level (it removes RT).


SPEEDRUN SETTINGS :

You can activate or desactivate Checkpoint Mode depending if you're running any% or checkpoint%.

You can set up a level number (from 0 to 12 - Mansion to Reprise) for reloading faster.


CUSTOMIZE :

You can change the text colour and order the different timers you want (GT must remain at least).
Please choose a colour so that there is enough contrast with the game.