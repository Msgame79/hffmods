["Speedrun-Practice Tools" for Human: Fall Flat]
Please follow the instructions below!

==HOW TO INSTALL THE "SPEEDRUN-PRACTICE TOOLS"==
1)	Download the current 32-bit (x86) version of BepInEx from https://github.com/BepInEx/BepInEx/releases
	a)	i.e. "BepInEx_x86_#.#.#.#.zip"
2)	Extract *all* the contents of the .zip into your "Human: Fall Flat" Steam directory
	b)	i.e. "C:\Program Files (x86)\Steam\steamapps\common\Human Fall Flat"
3)	Launch Human: Fall Flat (so that BepInEx can generate folders/files)
4)	Close Human: Fall Flat when you reach the menu
4)	Extract HFF_SpeedTools.zip into "BepInEx\plugins" (which should be inside your "Human: Fall Flat" Steam directory)
5)	Launch Human: Fall Flat and check the top-left corner; if you see a message with instructions then you are finished

==HOW TO USE AFTER INSTALL==
1)	Press "Numpad-Enter" on your keyboard to open the "Speedrun-Practice Tools" menu,
	OR
	Open the console and type "help" to see available commands

==DISCLAIMER==
Opening the "Speedrun-Practice Tools" Menu (done via "Numpad-Enter" on the keyboard) and/or opening the console invalidates speedruns for that game session.

Restart your game when you are finished practicing with the "Speedrun-Practice Tools".