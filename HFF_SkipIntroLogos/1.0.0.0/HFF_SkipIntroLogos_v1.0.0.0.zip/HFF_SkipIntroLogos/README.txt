["Skip Intro Logos" for Human: Fall Flat]
Please follow the instructions below!

==HOW TO INSTALL "SKIP INTRO LOGOS"==
1)	Download the current 32-bit (x86) version of BepInEx from https://github.com/BepInEx/BepInEx/releases
	a)	i.e. "BepInEx_x86_#.#.#.#.zip"
2)	Extract *all* the contents of the .zip into your "Human: Fall Flat" Steam directory
	b)	i.e. "C:\Program Files (x86)\Steam\steamapps\common\Human Fall Flat"
3)	Launch Human: Fall Flat (so that BepInEx can generate folders/files)
4)	Close Human: Fall Flat when you reach the menu
4)	Extract HFF_SkipIntroLogos.zip into "BepInEx\plugins" (which should be inside your "Human: Fall Flat" Steam directory)
5)	Launch Human: Fall Flat; if you start at the main menu then you are finished